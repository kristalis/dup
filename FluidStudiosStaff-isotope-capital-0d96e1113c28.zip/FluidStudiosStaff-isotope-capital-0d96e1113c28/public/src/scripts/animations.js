/**
 * Animations.
 *
 * Instantiate WowJS effects.
 */

const animations = () => {
  const wow = new WOW(); // eslint-disable-line no-undef

  wow.init();
};

animations();
