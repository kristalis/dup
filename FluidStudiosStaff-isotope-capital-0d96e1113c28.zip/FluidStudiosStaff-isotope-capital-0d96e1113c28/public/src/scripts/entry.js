/**
 * Entry.
 *
 * Module entry point.
 */

import "./animations";
import "./slick-slides";
import "./accordions";
import './navigation';